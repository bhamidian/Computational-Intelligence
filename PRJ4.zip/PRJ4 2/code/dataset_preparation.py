def create_distnce_matrix(input_path: str):
    # TODO: read data from file and create distance matrix
    pass

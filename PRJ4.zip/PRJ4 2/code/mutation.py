from individual import Individual


def mutation1(individual: Individual):
    # TODO: this method applies mutation on an individual
    pass

from individual import Individual


def evaluate_all(individual_list: list[Individual]):
    for individual in individual_list:
        evaluate(individual)


def evaluate(individual: Individual):
    # TODO: this method computes fitness (based on the TSP problem) and updates the fitness attribute of the individual parameter (individual.fitness=new_fitness)
    # hint: as taught by Dr. Ebadzadeh in the class, you may use -c to reverse the fitness value c
    pass

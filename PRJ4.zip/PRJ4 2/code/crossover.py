from individual import Individual


def cross_over(parent1: Individual, parent2: Individual):
    # TOOD
    pass